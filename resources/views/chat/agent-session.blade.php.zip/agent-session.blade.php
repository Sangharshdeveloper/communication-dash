@extends('layouts.app')
@section('title', 'Chat with ' . $session->customer->name)

@push('styles')
<style>
/* ── Layout ── */
.chat-shell{
  display:grid;grid-template-columns:1fr 280px;gap:0;
  height:calc(100vh - 140px);max-height:calc(100vh - 140px);
  border-radius:12px;overflow:hidden;
  border:1px solid #e5e7eb;background:#fff;
  margin-top:16px;
}
@media(max-width:900px){.chat-shell{grid-template-columns:1fr}.info-side{display:none}}

/* ── Chat main ── */
.chat-side{display:flex;flex-direction:column;overflow:hidden;background:#efeae2}
.chat-hdr{
  background: linear-gradient(135deg, #c4a366, #a8894f);
  color:#fff;padding:12px 18px;
  display:flex;align-items:center;gap:12px;
  flex-shrink:0;
}
.hdr-back{
  width:36px;height:36px;border-radius:50%;
  background:rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;
  font-size:16px;color:#fff;cursor:pointer;text-decoration:none;transition:background .15s;
}
.hdr-back:hover{background:rgba(255,255,255,.25)}
.hdr-av{
  width:40px;height:40px;border-radius:50%;
  background:rgba(255,255,255,.25);display:flex;align-items:center;justify-content:center;
  font-size:15px;font-weight:700;color:#fff;
  border:2px solid rgba(255,255,255,.4);
}
.hdr-info{flex:1;min-width:0}
.hdr-name{font-size:15px;font-weight:700;color:#fff;line-height:1.2}
.hdr-status{font-size:12px;color:rgba(255,255,255,.85);display:flex;align-items:center;gap:5px;margin-top:2px}
.hdr-status .dot{width:6px;height:6px;border-radius:50%;background:#4ade80}

/* ── Messages ── */
.chat-messages{
  flex:1;overflow-y:auto;padding:16px;
  display:flex;flex-direction:column;gap:3px;
  background-image:
    radial-gradient(circle at 25% 25%, rgba(0,0,0,.02) 1px, transparent 1px),
    radial-gradient(circle at 75% 75%, rgba(0,0,0,.02) 1px, transparent 1px);
  background-size:40px 40px;
}
.chat-messages::-webkit-scrollbar{width:4px}
.chat-messages::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:2px}

.msg-wrap{display:flex;gap:8px;align-items:flex-end;animation:mIn .15s ease}
@keyframes mIn{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
.msg-wrap.mine{flex-direction:row-reverse}

.msg-av{
  width:30px;height:30px;border-radius:50%;
  display:flex;align-items:center;justify-content:center;
  color:#fff;font-weight:700;font-size:12px;flex-shrink:0;
  background:linear-gradient(135deg,#006B3C,#00994d);
}
.msg-wrap.mine .msg-av{display:none}

.msg-grp{max-width:70%;display:flex;flex-direction:column;gap:2px}
.msg-wrap.mine .msg-grp{align-items:flex-end}

.bubble{
  padding:8px 12px;border-radius:8px;font-size:14px;line-height:1.45;
  word-break:break-word;position:relative;
  box-shadow:0 1px 1px rgba(0,0,0,.08);
}
.msg-wrap:not(.mine) .bubble{background:#fff;color:#111827;border-top-left-radius:3px}
.msg-wrap.mine .bubble{background:#d9fdd3;color:#111827;border-top-right-radius:3px}

.bubble-footer{
  display:flex;align-items:center;justify-content:flex-end;gap:4px;
  font-size:10px;color:#6b7280;margin-top:2px;
}
.read-ticks{font-size:12px;line-height:1;margin-left:1px}
.read-ticks.sent{color:#9ca3af}   /* ✓ single gray */
.read-ticks.read{color:#006B3C}    /* ✓✓ green (read) */

/* Attachments */
.att-pill{
  display:flex;align-items:center;gap:8px;
  background:rgba(0,0,0,.04);border-radius:8px;
  padding:7px 10px;margin-top:4px;cursor:pointer;
  border:1px solid rgba(0,0,0,.08);
  transition:background .15s;
}
.att-pill:hover{background:rgba(0,0,0,.08)}
.att-icon{font-size:18px;flex-shrink:0;line-height:1}
.att-name{font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:180px}
.att-size{font-size:10px;color:#6b7280;margin-top:1px}
.att-img{max-width:220px;border-radius:8px;display:block;margin-top:4px;cursor:pointer}

/* System message */
.sys-msg{
  background:rgba(255,255,255,.8);border-radius:6px;padding:5px 12px;
  font-size:12px;color:#6b7280;text-align:center;align-self:center;
  max-width:90%;margin:6px auto;border:1px solid rgba(0,0,0,.05);
}

/* Typing indicator */
.typing-ind{display:none;padding:6px 16px;font-size:12px;color:#6b7280}

/* ── Input bar ── */
.chat-input-bar{
  padding:10px 14px;background:#f0f2f5;flex-shrink:0;
  border-top:1px solid rgba(0,0,0,.05);
}
.file-chips{display:none;flex-wrap:wrap;gap:6px;padding:6px 4px}
.file-chips.active{display:flex}
.file-chip{
  display:flex;align-items:center;gap:6px;
  background:#fff;border:1px solid #e5e7eb;border-radius:20px;
  padding:4px 10px 4px 6px;font-size:12px;max-width:180px;
}
.file-chip .remove{cursor:pointer;color:#9ca3af;font-size:14px;line-height:1}

.input-grp{
  display:flex;align-items:flex-end;gap:8px;
}
.input-box{
  flex:1;background:#fff;border-radius:22px;
  padding:8px 8px 8px 14px;display:flex;align-items:flex-end;gap:6px;
  border:1px solid rgba(0,0,0,.06);transition:border-color .15s;
}
.input-box:focus-within{border-color:rgba(0,107,60,.3);box-shadow:0 0 0 3px rgba(0,107,60,.08)}
#agent-input{
  flex:1;resize:none;border:none;outline:none;background:transparent;
  font-size:14px;color:#111827;font-family:inherit;
  min-height:22px;max-height:100px;line-height:1.5;padding:2px 0;
}
.attach-icon{
  cursor:pointer;color:#6b7280;font-size:20px;line-height:1;padding:4px;
  transition:color .15s;
}
.attach-icon:hover{color:#006B3C}

.send-fab{
  width:42px;height:42px;border-radius:50%;flex-shrink:0;
  background:linear-gradient(135deg,#006B3C,#00994d);
  color:#fff;cursor:pointer;border:none;
  display:flex;align-items:center;justify-content:center;
  transition:all .2s;box-shadow:0 2px 8px rgba(0,107,60,.35);
}
.send-fab:hover{transform:scale(1.05);box-shadow:0 4px 12px rgba(0,107,60,.45)}
.send-fab:active{transform:scale(.95)}
.send-fab:disabled{opacity:.45;transform:none;box-shadow:none;cursor:not-allowed}

/* ── Right sidebar: customer info ── */
.info-side{
  background:#fff;border-left:1px solid #f3f4f6;
  overflow-y:auto;padding:20px;
}
.info-side::-webkit-scrollbar{width:4px}
.info-side::-webkit-scrollbar-thumb{background:#d1d5db;border-radius:2px}

.info-av{
  width:80px;height:80px;border-radius:50%;margin:0 auto 12px;
  background:linear-gradient(135deg,#006B3C,#00994d);
  display:flex;align-items:center;justify-content:center;
  color:#fff;font-weight:800;font-size:32px;
}
.info-name{text-align:center;font-size:17px;font-weight:700;color:#111827;margin-bottom:4px}
.info-role{text-align:center;margin-bottom:18px}

.info-group{margin-bottom:18px}
.info-group h4{
  font-size:11px;text-transform:uppercase;letter-spacing:.06em;
  color:#9ca3af;font-weight:700;margin-bottom:10px;
}
.info-item{display:flex;align-items:flex-start;gap:10px;padding:6px 0;font-size:13px}
.info-item-icon{color:#6b7280;width:18px;flex-shrink:0;font-size:14px;line-height:1.4}
.info-item-body{flex:1;min-width:0;color:#374151;word-break:break-word}

.action-row{
  display:flex;gap:6px;margin-bottom:16px;
}
.action-row button{
  flex:1;padding:8px;font-size:12px;font-weight:600;border-radius:8px;
  border:1px solid #e5e7eb;background:#fff;color:#374151;cursor:pointer;
  transition:all .15s;
}
.action-row button:hover{background:#f9fafb;border-color:#006B3C;color:#006B3C}

/* Lightbox */
#lb{
  display:none;position:fixed;inset:0;background:rgba(0,0,0,.9);z-index:9999;
  align-items:center;justify-content:center;padding:16px;
}
#lb.open{display:flex}
#lb img{max-width:100%;max-height:90vh;border-radius:8px}
#lb-close{
  position:absolute;top:20px;right:20px;
  background:rgba(255,255,255,.15);border:none;color:#fff;
  width:40px;height:40px;border-radius:50%;font-size:18px;cursor:pointer;
}

/* Toast */
#ag-toast{
  position:fixed;bottom:24px;left:50%;transform:translateX(-50%) translateY(20px);
  background:#111827;color:#fff;padding:10px 20px;border-radius:20px;
  font-size:13px;opacity:0;transition:all .25s;z-index:9999;
  white-space:nowrap;pointer-events:none;
}
#ag-toast.show{opacity:1;transform:translateX(-50%) translateY(0)}
</style>
@endpush

@section('content')
<div class="page-container" style="padding-top:16px;max-width:1400px">
  <a href="{{ route('direct-chat.agent.inbox') }}" style="font-size:13px;color:#6b7280;display:inline-flex;align-items:center;gap:4px">
    ← Back to Inbox
  </a>

  <div class="chat-shell">

    {{-- ═══ LEFT: Chat ═══ --}}
    <div class="chat-side">
      <div class="chat-hdr">
        <a href="{{ route('direct-chat.agent.inbox') }}" class="hdr-back">←</a>
        <div class="hdr-av">{{ strtoupper(substr($session->customer->name, 0, 1)) }}</div>
        <div class="hdr-info">
          <div class="hdr-name">{{ $session->customer->name }}</div>
          <div class="hdr-status">
            <div class="dot"></div>
            @if($session->customer_ref)
              Customer ID: {{ $session->customer_ref }}
            @else
              Direct customer
            @endif
          </div>
        </div>
      </div>

      <div class="chat-messages" id="messages">
        @forelse($messages as $msg)
          @if($msg['type'] === 'system')
            <div class="sys-msg" id="m-{{ $msg['id'] }}">{{ $msg['body'] }}</div>
          @else
            <div class="msg-wrap {{ $msg['mine'] ? 'mine' : '' }}" id="m-{{ $msg['id'] }}">
              @if(!$msg['mine'])
                <div class="msg-av">{{ $msg['initial'] ?? '' }}</div>
              @endif
              <div class="msg-grp">
                <div class="bubble">
                  @if($msg['body']){!! nl2br(e($msg['body'])) !!}@endif
                  @foreach($msg['attachments'] as $att)
                    @if($att['is_image'])
                      <img src="{{ $att['url'] }}" class="att-img" onclick="lightbox('{{ $att['url'] }}')" alt="{{ $att['name'] }}">
                    @else
                      <div class="att-pill" onclick="window.open('{{ $att['url'] }}')">
                        <span class="att-icon">{{ str_contains($att['mime'], 'pdf') ? '📄' : '📎' }}</span>
                        <div>
                          <div class="att-name">{{ $att['name'] }}</div>
                          <div class="att-size">{{ $att['size'] }}</div>
                        </div>
                      </div>
                    @endif
                  @endforeach
                  <div class="bubble-footer">
                    <span>{{ $msg['time'] }}</span>
                    @if($msg['mine'])
                      <span class="read-ticks {{ $msg['is_read'] ? 'read' : 'sent' }}">
                        {{ $msg['is_read'] ? '✓✓' : '✓' }}
                      </span>
                    @endif
                  </div>
                </div>
              </div>
            </div>
          @endif
        @empty
          <div class="sys-msg">No messages yet. Say hello! 👋</div>
        @endforelse
      </div>

      <div class="chat-input-bar">
        <div class="file-chips" id="file-chips"></div>
        <div class="input-grp">
          <div class="input-box">
            <textarea id="agent-input" rows="1" placeholder="Type a message…"
              oninput="resizeInput(this)" onkeydown="onKey(event)" maxlength="4000"></textarea>
            <label class="attach-icon" title="Attach file">
              📎<input type="file" style="display:none" multiple id="agent-files"
                accept=".jpg,.jpeg,.png,.gif,.pdf,.doc,.docx,.xls,.xlsx,.txt,.zip"
                onchange="filesPicked(this)">
            </label>
          </div>
          <button class="send-fab" id="send-btn" onclick="agentSend()" disabled>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="white">
              <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
            </svg>
          </button>
        </div>
      </div>
    </div>

    {{-- ═══ RIGHT: Customer info ═══ --}}
    <div class="info-side">
      <div class="info-av">{{ strtoupper(substr($session->customer->name, 0, 1)) }}</div>
      <div class="info-name">{{ $session->customer->name }}</div>
      <div class="info-role">
        <span class="badge badge-success" style="font-size:11px">🟢 {{ ucfirst($session->status) }}</span>
      </div>

      <div class="action-row">
        <button onclick="copyLink()">📋 Copy Link</button>
        <button onclick="window.open('mailto:{{ $session->customer->email }}')">✉️ Email</button>
      </div>

      <div class="info-group">
        <h4>Customer Details</h4>
        <div class="info-item">
          <span class="info-item-icon">👤</span>
          <div class="info-item-body">
            <div style="font-size:11px;color:#9ca3af">Customer Ref</div>
            {{ $session->customer_ref ?? '—' }}
          </div>
        </div>
        <div class="info-item">
          <span class="info-item-icon">📧</span>
          <div class="info-item-body">
            <div style="font-size:11px;color:#9ca3af">Email</div>
            <span style="font-size:12px">{{ $session->customer->email }}</span>
          </div>
        </div>
        @if($session->customer->phone)
        <div class="info-item">
          <span class="info-item-icon">📱</span>
          <div class="info-item-body">
            <div style="font-size:11px;color:#9ca3af">Phone</div>
            {{ $session->customer->phone }}
          </div>
        </div>
        @endif
      </div>

      <div class="info-group">
        <h4>Session Info</h4>
        <div class="info-item">
          <span class="info-item-icon">🕐</span>
          <div class="info-item-body">
            <div style="font-size:11px;color:#9ca3af">Started</div>
            {{ $session->created_at->format('d M Y · H:i') }}
          </div>
        </div>
        <div class="info-item">
          <span class="info-item-icon">💬</span>
          <div class="info-item-body">
            <div style="font-size:11px;color:#9ca3af">Last Activity</div>
            {{ $session->last_activity_at?->diffForHumans() ?? '—' }}
          </div>
        </div>
        <div class="info-item">
          <span class="info-item-icon">⏰</span>
          <div class="info-item-body">
            <div style="font-size:11px;color:#9ca3af">Expires</div>
            <span style="font-size:12px">{{ $session->expires_at?->diffForHumans() ?? '—' }}</span>
          </div>
        </div>
      </div>

      <div class="info-group">
        <h4>Resumable Link</h4>
        <p style="font-size:11px;color:#9ca3af;margin-bottom:8px;line-height:1.5">
          Send this to the customer to resume:
        </p>
        <button onclick="copyLink()" style="width:100%;background:#e8f5ee;color:#006B3C;border:1px solid #bbf7d0;border-radius:8px;padding:9px;font-size:12px;font-weight:600;cursor:pointer">
          📋 Copy Session Link
        </button>
      </div>
    </div>
  </div>
</div>

<!-- Lightbox -->
<div id="lb" onclick="closeLb()">
  <button id="lb-close" onclick="closeLb()">✕</button>
  <img id="lb-img" src="" alt="">
</div>

<div id="ag-toast"></div>
@endsection

@push('scripts')
<script>
const TOKEN      = '{{ $session->session_token }}';
const SEND_URL   = '{{ route("direct-chat.send") }}';
const POLL_URL   = '{{ route("direct-chat.poll") }}';
const CSRF       = '{{ csrf_token() }}';
const AGENT_ID   = {{ $session->agent_id }};
const RESUME_URL = '{{ url("/c/".$session->agent_id) }}?cid={{ urlencode($session->customer_ref ?? "") }}&token={{ $session->session_token }}';

let lastMsgId   = {{ !empty($messages) ? end($messages)['id'] : 0 }};
let pendingFiles = [];
let sending     = false;

// ── Init ─────────────────────────────────────────────────────────────────────
window.addEventListener('load', () => {
  scrollBottom();
  startPoll();
  document.getElementById('agent-input').focus();
});

// ── Auto-resize ──────────────────────────────────────────────────────────────
function resizeInput(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 100) + 'px';
  updateSendButton();
}
function updateSendButton() {
  const has = document.getElementById('agent-input').value.trim() !== '' || pendingFiles.length > 0;
  document.getElementById('send-btn').disabled = !has || sending;
}

function onKey(e) {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); agentSend(); }
}

// ── File pick ────────────────────────────────────────────────────────────────
function filesPicked(input) {
  Array.from(input.files).forEach(f => {
    if (f.size > 10 * 1024 * 1024) { toast('File too large (max 10 MB)'); return; }
    pendingFiles.push(f);
  });
  input.value = '';
  renderChips();
  updateSendButton();
}
function renderChips() {
  const wrap = document.getElementById('file-chips');
  if (!pendingFiles.length) { wrap.className = 'file-chips'; wrap.innerHTML = ''; return; }
  wrap.className = 'file-chips active';
  wrap.innerHTML = pendingFiles.map((f, i) =>
    `<div class="file-chip">
       <span>${fileIcon(f.type)}</span>
       <span>${esc(f.name)}</span>
       <span class="remove" onclick="removeFile(${i})">✕</span>
     </div>`
  ).join('');
}
function removeFile(i) { pendingFiles.splice(i, 1); renderChips(); updateSendButton(); }
function fileIcon(m) {
  if (m.startsWith('image/')) return '🖼️';
  if (m.includes('pdf'))       return '📄';
  if (m.includes('word'))      return '📝';
  return '📎';
}

// ── Send ─────────────────────────────────────────────────────────────────────
async function agentSend() {
  if (sending) return;
  const inp  = document.getElementById('agent-input');
  const body = inp.value.trim();
  if (!body && !pendingFiles.length) return;

  sending = true;
  document.getElementById('send-btn').disabled = true;

  const fd = new FormData();
  fd.append('session_token', TOKEN);
  if (body) fd.append('body', body);
  pendingFiles.forEach(f => fd.append('attachments[]', f));

  // Optimistic bubble
  const optId = 'opt_' + Date.now();
  appendMsg({
    id: optId, body, type: pendingFiles.length ? 'attachment' : 'text',
    mine: true, sender_name: 'You', initial: 'Y',
    time: new Date().toLocaleTimeString('en-US', {hour:'2-digit',minute:'2-digit',hour12:false}),
    is_read: false, attachments: [],
    pending: true,
  });

  inp.value = '';
  inp.style.height = 'auto';
  pendingFiles = [];
  renderChips();
  scrollBottom(true);

  try {
    const res  = await fetch(SEND_URL, {
      method: 'POST',
      headers: { 'X-CSRF-TOKEN': CSRF, 'Accept': 'application/json' },
      body: fd,
    });
    if (!res.ok) throw new Error('Send failed');
    const data = await res.json();

    const opt = document.getElementById('m-' + optId);
    if (opt) opt.remove();

    appendMsg(data);
    lastMsgId = Math.max(lastMsgId, data.id);
    scrollBottom(true);
  } catch (e) {
    toast('❌ Failed to send');
    const opt = document.getElementById('m-' + optId);
    if (opt) opt.style.opacity = '.4';
  } finally {
    sending = false;
    updateSendButton();
    document.getElementById('agent-input').focus();
  }
}

// ── Poll ─────────────────────────────────────────────────────────────────────
async function poll() {
  try {
    const url = new URL(POLL_URL, window.location.origin);
    url.searchParams.set('session_token', TOKEN);
    url.searchParams.set('after_id', lastMsgId);

    const res = await fetch(url, {
      headers: { 'Accept': 'application/json' }
    });
    if (!res.ok) return;
    const data = await res.json();
    const msgs        = data.messages     || [];
    const readUpdates = data.read_updates || [];

    // Update read ticks for our sent messages
    readUpdates.forEach(id => {
      const t = document.querySelector('#m-' + id + ' .read-ticks');
      if (t) { t.textContent = '✓✓'; t.classList.remove('sent'); t.classList.add('read'); }
    });

    if (!msgs.length) return;

    const wrap = document.getElementById('messages');
    const atBot = wrap.scrollHeight - wrap.scrollTop - wrap.clientHeight < 80;

    msgs.forEach(msg => {
      if (document.getElementById('m-' + msg.id)) return;
      appendMsg(msg);
      lastMsgId = Math.max(lastMsgId, msg.id);
    });

    if (atBot) scrollBottom(true);
  } catch (_) {}
}
function startPoll() {
  let t = setInterval(poll, 3000);
  document.addEventListener('visibilitychange', () => {
    clearInterval(t);
    if (!document.hidden) t = setInterval(poll, 3000);
  });
}

// ── Append ──────────────────────────────────────────────────────────────────
function appendMsg(msg) {
  const wrap = document.getElementById('messages');

  if (msg.type === 'system') {
    const el = document.createElement('div');
    el.className = 'sys-msg'; el.id = 'm-' + msg.id;
    el.textContent = msg.body;
    wrap.appendChild(el);
    return;
  }

  const row = document.createElement('div');
  row.className = 'msg-wrap' + (msg.mine ? ' mine' : '');
  row.id = 'm-' + msg.id;
  if (msg.pending) row.style.opacity = '.7';

  const bodyHtml = msg.body
    ? msg.body.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'<br>')
    : '';

  const attsHtml = (msg.attachments || []).map(att => att.is_image
    ? `<img src="${att.url}" class="att-img" onclick="lightbox('${att.url}')" alt="${esc(att.name)}">`
    : `<div class="att-pill" onclick="window.open('${att.url}')">
         <span class="att-icon">${fileIcon(att.mime)}</span>
         <div>
           <div class="att-name">${esc(att.name)}</div>
           <div class="att-size">${att.size}</div>
         </div>
       </div>`
  ).join('');

  const ticks = msg.mine
    ? `<span class="read-ticks ${msg.is_read ? 'read' : 'sent'}">${msg.is_read ? '✓✓' : '✓'}</span>`
    : '';

  const avHtml = msg.mine ? '' : `<div class="msg-av">${msg.initial}</div>`;

  row.innerHTML = `
    ${avHtml}
    <div class="msg-grp">
      <div class="bubble">
        ${bodyHtml}${attsHtml}
        <div class="bubble-footer">
          <span>${msg.time}</span>
          ${ticks}
        </div>
      </div>
    </div>`;

  wrap.appendChild(row);
}

function scrollBottom(smooth = false) {
  const w = document.getElementById('messages');
  w.scrollTo({ top: w.scrollHeight, behavior: smooth ? 'smooth' : 'instant' });
}

function lightbox(src) {
  document.getElementById('lb-img').src = src;
  document.getElementById('lb').classList.add('open');
}
function closeLb() { document.getElementById('lb').classList.remove('open'); }

function copyLink() {
  navigator.clipboard.writeText(RESUME_URL).then(() => toast('Link copied!'));
}
function toast(msg) {
  const t = document.getElementById('ag-toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(window._tt);
  window._tt = setTimeout(() => t.classList.remove('show'), 2500);
}
function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
</script>
@endpush
