@extends('layouts.app')

@section('title', 'Team Chat')

@push('styles')
<style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&display=swap');

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
        font-family: 'DM Sans', sans-serif;
        background: #0a0f1e;
        overflow: hidden;
        height: 100vh;
    }

    /* ── Layout ── */
    .chat-app {
        display: flex;
        height: calc(100vh - 64px); /* subtract navbar */
        overflow: hidden;
    }

    /* ── Sidebar ── */
    .sidebar {
        width: 300px;
        flex-shrink: 0;
        background: #111827;
        border-right: 1px solid rgba(255,255,255,.07);
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }

    .sidebar-header {
        padding: 20px 18px 14px;
        border-bottom: 1px solid rgba(255,255,255,.07);
    }

    .sidebar-title {
        font-size: 18px;
        font-weight: 700;
        color: #f9fafb;
        letter-spacing: -.02em;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .sidebar-title .dot {
        width: 8px; height: 8px;
        border-radius: 50%;
        background: #c4a366;
        box-shadow: 0 0 8px #c4a366;
        animation: pulse-dot 2s infinite;
    }

    @keyframes pulse-dot {
        0%, 100% { opacity: 1; }
        50%       { opacity: .4; }
    }

    .sidebar-subtitle {
        font-size: 12px;
        color: #6b7280;
        margin-top: 3px;
    }

    .rooms-list {
        flex: 1;
        overflow-y: auto;
        padding: 8px 0;
    }

    .rooms-list::-webkit-scrollbar { width: 4px; }
    .rooms-list::-webkit-scrollbar-track { background: transparent; }
    .rooms-list::-webkit-scrollbar-thumb { background: #374151; border-radius: 2px; }

    .room-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 10px 18px;
        cursor: pointer;
        transition: background .15s;
        border-radius: 0;
        position: relative;
    }

    .room-item:hover { background: rgba(255,255,255,.04); }

    .room-item.active {
        background: rgba(0, 107, 60, .2);
        border-right: 3px solid #006B3C;
    }

    .room-icon {
        width: 42px; height: 42px;
        border-radius: 12px;
        display: flex; align-items: center; justify-content: center;
        font-size: 18px; flex-shrink: 0;
    }

    .room-icon.general      { background: rgba(99,102,241,.2); }
    .room-icon.claims       { background: rgba(245,158,11,.2); }
    .room-icon.underwriting { background: rgba(16,185,129,.2); }
    .room-icon.support      { background: rgba(239,68,68,.2); }

    .room-info { flex: 1; min-width: 0; }

    .room-name {
        font-size: 14px; font-weight: 600;
        color: #f3f4f6;
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }

    .room-last-msg {
        font-size: 12px; color: #6b7280;
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        margin-top: 2px;
    }

    .room-time {
        font-size: 11px; color: #4b5563;
        flex-shrink: 0;
    }

    /* ── Main chat area ── */
    .chat-main {
        flex: 1;
        display: flex;
        flex-direction: column;
        background: #0f172a;
        overflow: hidden;
        position: relative;
    }

    /* Subtle grid background */
    .chat-main::before {
        content: '';
        position: absolute;
        inset: 0;
        background-image:
            linear-gradient(rgba(255,255,255,.015) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,.015) 1px, transparent 1px);
        background-size: 32px 32px;
        pointer-events: none;
    }

    /* Chat header */
    .chat-header {
        padding: 14px 20px;
        background: rgba(17, 24, 39, .95);
        border-bottom: 1px solid rgba(255,255,255,.07);
        display: flex;
        align-items: center;
        gap: 14px;
        z-index: 10;
        backdrop-filter: blur(12px);
    }

    .chat-header-icon {
        width: 40px; height: 40px; border-radius: 10px;
        display: flex; align-items: center; justify-content: center; font-size: 18px;
    }

    .chat-header-info h2 {
        font-size: 15px; font-weight: 700; color: #f9fafb;
    }

    .chat-header-info p {
        font-size: 12px; color: #6b7280; margin-top: 1px;
    }

    .chat-header-actions { margin-left: auto; display: flex; gap: 8px; }

    .icon-btn {
        width: 36px; height: 36px; border-radius: 8px;
        background: rgba(255,255,255,.05); border: 1px solid rgba(255,255,255,.08);
        display: flex; align-items: center; justify-content: center;
        cursor: pointer; color: #9ca3af; font-size: 16px;
        transition: all .15s;
    }
    .icon-btn:hover { background: rgba(255,255,255,.1); color: #f3f4f6; }

    /* Messages area */
    .messages-area {
        flex: 1;
        overflow-y: auto;
        padding: 20px;
        display: flex;
        flex-direction: column;
        gap: 2px;
        position: relative;
        z-index: 1;
    }

    .messages-area::-webkit-scrollbar { width: 4px; }
    .messages-area::-webkit-scrollbar-track { background: transparent; }
    .messages-area::-webkit-scrollbar-thumb { background: #1f2937; border-radius: 2px; }

    /* Date separator */
    .date-sep {
        text-align: center; margin: 16px 0 8px;
        font-size: 11px; color: #4b5563; letter-spacing: .05em;
        text-transform: uppercase;
        display: flex; align-items: center; gap: 10px;
    }
    .date-sep::before, .date-sep::after {
        content: ''; flex: 1; height: 1px; background: rgba(255,255,255,.06);
    }

    /* Message row */
    .msg-row {
        display: flex;
        gap: 10px;
        align-items: flex-end;
        margin-bottom: 2px;
        animation: fadeUp .2s ease;
    }

    @keyframes fadeUp {
        from { opacity: 0; transform: translateY(8px); }
        to   { opacity: 1; transform: translateY(0); }
    }

    .msg-row.mine { flex-direction: row-reverse; }

    .msg-avatar {
        width: 32px; height: 32px; border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-size: 12px; font-weight: 700; flex-shrink: 0;
        margin-bottom: 2px;
    }

    .msg-row.mine .msg-avatar { display: none; }

    .msg-group { display: flex; flex-direction: column; gap: 2px; max-width: 65%; }
    .msg-row.mine .msg-group { align-items: flex-end; }

    .msg-sender {
        font-size: 11px; font-weight: 600;
        color: #9ca3af; margin-bottom: 3px; margin-left: 2px;
    }

    .msg-bubble {
        padding: 9px 14px;
        border-radius: 16px;
        font-size: 14px; line-height: 1.5;
        word-break: break-word;
        position: relative;
    }

    /* Theirs */
    .msg-row:not(.mine) .msg-bubble {
        background: #1e293b;
        color: #e2e8f0;
        border-bottom-left-radius: 4px;
    }

    /* Mine */
    .msg-row.mine .msg-bubble {
        background: linear-gradient(135deg, #c4a366, #d6b77a);
        color: #fff;
        border-bottom-right-radius: 4px;
    }

    .msg-time {
        font-size: 10px; color: #4b5563;
        margin-top: 2px; padding: 0 2px;
    }

    .msg-row.mine .msg-time {
        color: rgba(255,255,255,.5);
        text-align: right;
    }

    /* Role badge inside message */
    .role-pill {
        display: inline-block;
        font-size: 9px; font-weight: 700; letter-spacing: .06em;
        text-transform: uppercase; padding: 1px 5px;
        border-radius: 4px; margin-left: 6px; vertical-align: middle;
    }
    .role-admin    { background: rgba(239,68,68,.2);   color: #fca5a5; }
    .role-agent    { background: rgba(59,130,246,.2);  color: #93c5fd; }
    .role-auditor  { background: rgba(245,158,11,.2);  color: #fcd34d; }
    .role-customer { background: rgba(107,114,128,.2); color: #9ca3af; }

    /* Typing indicator */
    .typing-indicator {
        display: none;
        padding: 6px 20px;
        font-size: 12px; color: #6b7280;
        align-items: center; gap: 6px;
    }
    .typing-dots { display: flex; gap: 3px; }
    .typing-dots span {
        width: 5px; height: 5px; border-radius: 50%;
        background: #4b5563; animation: bounce .8s infinite;
    }
    .typing-dots span:nth-child(2) { animation-delay: .15s; }
    .typing-dots span:nth-child(3) { animation-delay: .3s; }
    @keyframes bounce {
        0%, 100% { transform: translateY(0); }
        40%       { transform: translateY(-4px); }
    }

    /* Input bar */
    .chat-input-bar {
        padding: 12px 16px;
        background: rgba(17, 24, 39, .95);
        border-top: 1px solid rgba(255,255,255,.07);
        display: flex;
        gap: 10px;
        align-items: flex-end;
        z-index: 10;
        backdrop-filter: blur(12px);
    }

    .input-wrap {
        flex: 1;
        background: #1e293b;
        border: 1px solid rgba(255,255,255,.08);
        border-radius: 24px;
        display: flex;
        align-items: flex-end;
        padding: 8px 16px;
        transition: border-color .15s;
    }

    .input-wrap:focus-within {
        border-color: rgba(0,107,60,.6);
        box-shadow: 0 0 0 3px rgba(0,107,60,.1);
    }

    #message-input {
        flex: 1; background: transparent; border: none; outline: none;
        color: #f1f5f9; font-size: 14px; font-family: inherit;
        resize: none; max-height: 120px; line-height: 1.5;
        padding: 2px 0;
    }

    #message-input::placeholder { color: #4b5563; }

    .send-btn {
        width: 44px; height: 44px; border-radius: 50%;
        background: linear-gradient(135deg, #006B3C, #00994d);
        border: none; cursor: pointer;
        display: flex; align-items: center; justify-content: center;
        flex-shrink: 0; transition: all .2s;
        box-shadow: 0 4px 12px rgba(0,107,60,.4);
    }

    .send-btn:hover { transform: scale(1.08); box-shadow: 0 6px 16px rgba(0,107,60,.5); }
    .send-btn:active { transform: scale(.95); }
    .send-btn svg { width: 18px; height: 18px; fill: white; }

    /* Empty state */
    .empty-state {
        flex: 1; display: flex; flex-direction: column;
        align-items: center; justify-content: center;
        color: #374151; text-align: center; gap: 12px;
    }
    .empty-state .icon { font-size: 48px; }
    .empty-state h3 { font-size: 16px; font-weight: 600; color: #4b5563; }
    .empty-state p  { font-size: 13px; color: #374151; }

    /* Loading spinner */
    .msg-loading {
        display: flex; justify-content: center; padding: 20px;
    }
    .spin {
        width: 20px; height: 20px; border: 2px solid #1f2937;
        border-top-color: #006B3C; border-radius: 50%;
        animation: spin .7s linear infinite;
    }
    @keyframes spin { to { transform: rotate(360deg); } }

    /* Scrollbar always visible on messages area */
    .messages-area { scrollbar-width: thin; scrollbar-color: #1f2937 transparent; }

    /* Responsive */
    @media (max-width: 768px) {
        .sidebar { width: 70px; }
        .room-name, .room-last-msg, .room-time, .sidebar-title, .sidebar-subtitle { display: none; }
        .room-item { justify-content: center; padding: 12px 0; }
        .room-info { display: none; }
        .sidebar-header { padding: 14px 8px; }
    }
</style>
@endpush

@section('content')
<div class="chat-app">

    {{-- ── Sidebar ── --}}
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-title">
                <div class="dot"></div>
                Team Chat
            </div>
            <div class="sidebar-subtitle">{{ $rooms->count() }} channels</div>
        </div>

        <div class="rooms-list">
            @foreach ($rooms as $room)
            @php
                $icons = ['general'=>'💬','claims'=>'📋','underwriting'=>'📊','support'=>'🎧'];
                $icon  = $icons[$room->type] ?? '💬';
            @endphp
            <div class="room-item {{ $loop->first ? 'active' : '' }}"
                 data-room-id="{{ $room->id }}"
                 onclick="switchRoom({{ $room->id }}, '{{ $room->name }}', '{{ $room->type }}', '{{ $room->description }}')">
                <div class="room-icon {{ $room->type }}">{{ $icon }}</div>
                <div class="room-info">
                    <div class="room-name">{{ $room->name }}</div>
                    <div class="room-last-msg">
                        {{ $room->latestMessage ? Str::limit($room->latestMessage->message, 30) : 'No messages yet' }}
                    </div>
                </div>
                <div class="room-time">
                    {{ $room->latestMessage?->created_at?->format('H:i') ?? '' }}
                </div>
            </div>
            @endforeach
        </div>
    </aside>

    {{-- ── Main chat ── --}}
    <div class="chat-main" id="chat-main">

        @if ($activeRoom)
        {{-- Header --}}
        <div class="chat-header" id="chat-header">
            <div class="chat-header-icon {{ $activeRoom->type }}">
                {{ ['general'=>'💬','claims'=>'📋','underwriting'=>'📊','support'=>'🎧'][$activeRoom->type] ?? '💬' }}
            </div>
            <div class="chat-header-info">
                <h2 id="room-title">{{ $activeRoom->name }}</h2>
                <p id="room-desc">{{ $activeRoom->description }}</p>
            </div>
            <div class="chat-header-actions">
                <div class="icon-btn" title="Back to Dashboard" onclick="window.location='{{ route('dashboard') }}'">🏠</div>
            </div>
        </div>

        {{-- Messages --}}
        <div class="messages-area" id="messages-area">
            <div class="date-sep">Today</div>

            @if ($messages->isEmpty())
            <div class="empty-state">
                <div class="icon">💬</div>
                <h3>No messages yet</h3>
                <p>Be the first to start the conversation!</p>
            </div>
            @else
                @foreach ($messages as $msg)
                @php $mine = $msg->user_id === auth()->id(); @endphp
                <div class="msg-row {{ $mine ? 'mine' : '' }}" id="msg-{{ $msg->id }}">
                    @if (!$mine)
                    <div class="msg-avatar"
                         style="background: {{ ['admin'=>'#ef4444','agent'=>'#3b82f6','auditor'=>'#f59e0b','customer'=>'#6b7280'][$msg->user->role] ?? '#6b7280' }}">
                        {{ strtoupper(substr($msg->user->name, 0, 1)) }}
                    </div>
                    @endif
                    <div class="msg-group">
                        @if (!$mine)
                        <div class="msg-sender">
                            {{ $msg->user->name }}
                            <span class="role-pill role-{{ $msg->user->role }}">{{ $msg->user->role }}</span>
                        </div>
                        @endif
                        <div class="msg-bubble">{{ $msg->message }}</div>
                        <div class="msg-time">{{ $msg->created_at->format('H:i') }}</div>
                    </div>
                </div>
                @endforeach
            @endif
        </div>

        {{-- Typing indicator --}}
        <div class="typing-indicator" id="typing-indicator">
            <div class="typing-dots">
                <span></span><span></span><span></span>
            </div>
            <span id="typing-text">Someone is typing…</span>
        </div>

        {{-- Input bar --}}
        <div class="chat-input-bar">
            <div class="input-wrap">
                <textarea
                    id="message-input"
                    placeholder="Type a message…"
                    rows="1"
                    maxlength="2000"
                ></textarea>
            </div>
            <button class="send-btn" id="send-btn" onclick="sendMessage()">
                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
                </svg>
            </button>
        </div>

        @else
        <div class="empty-state" style="flex:1;display:flex;">
            <div class="icon">💬</div>
            <h3>No channels available</h3>
            <p>Run <code>php artisan db:seed --class=ChatRoomSeeder</code> to create channels.</p>
        </div>
        @endif

    </div>
</div>
@endsection

@push('scripts')
<script>
const ME        = {{ auth()->id() }};
const CSRF      = document.querySelector('meta[name="csrf-token"]')?.content
                  || '{{ csrf_token() }}';

let currentRoomId = {{ $activeRoom?->id ?? 'null' }};
let lastMsgId     = {{ $messages->last()?->id ?? 0 }};
let pollTimer     = null;

// ── Auto-resize textarea ────────────────────────────────────────────────────
const input = document.getElementById('message-input');
if (input) {
    input.addEventListener('input', function () {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 120) + 'px';
    });
    input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
}

// ── Scroll to bottom ────────────────────────────────────────────────────────
function scrollBottom(smooth = false) {
    const area = document.getElementById('messages-area');
    if (!area) return;
    area.scrollTo({ top: area.scrollHeight, behavior: smooth ? 'smooth' : 'instant' });
}

// ── Render a message bubble ─────────────────────────────────────────────────
const roleColors = { admin: '#ef4444', agent: '#3b82f6', auditor: '#f59e0b', customer: '#6b7280' };

function renderMessage(msg) {
    const row = document.createElement('div');
    row.className = 'msg-row' + (msg.mine ? ' mine' : '');
    row.id = 'msg-' + msg.id;

    const avatarHtml = msg.mine ? '' : `
        <div class="msg-avatar" style="background:${roleColors[msg.user_role] || '#6b7280'}">
            ${msg.user_initial}
        </div>`;

    const senderHtml = msg.mine ? '' : `
        <div class="msg-sender">
            ${msg.user_name}
            <span class="role-pill role-${msg.user_role}">${msg.user_role}</span>
        </div>`;

    row.innerHTML = `
        ${avatarHtml}
        <div class="msg-group">
            ${senderHtml}
            <div class="msg-bubble">${escapeHtml(msg.message)}</div>
            <div class="msg-time">${msg.time}</div>
        </div>`;

    return row;
}

function escapeHtml(str) {
    return str
        .replace(/&/g,'&amp;').replace(/</g,'&lt;')
        .replace(/>/g,'&gt;').replace(/"/g,'&quot;')
        .replace(/\n/g,'<br>');
}

// ── Send message ─────────────────────────────────────────────────────────────
async function sendMessage() {
    if (!currentRoomId) return;
    const text = input.value.trim();
    if (!text) return;

    input.value = '';
    input.style.height = 'auto';
    document.getElementById('send-btn').disabled = true;

    try {
        const res = await fetch(`/chat/${currentRoomId}/send`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': CSRF,
                'Accept': 'application/json',
            },
            body: JSON.stringify({ message: text }),
        });

        if (!res.ok) throw new Error('Send failed');

        const msg = await res.json();
        lastMsgId = msg.id;

        // Remove empty state if present
        const empty = document.querySelector('.empty-state');
        if (empty) empty.remove();

        const area = document.getElementById('messages-area');
        area.appendChild(renderMessage(msg));
        scrollBottom(true);
    } catch (e) {
        input.value = text; // restore on failure
        alert('Failed to send message. Please try again.');
    } finally {
        document.getElementById('send-btn').disabled = false;
        input.focus();
    }
}

// ── Poll for new messages ────────────────────────────────────────────────────
async function pollMessages() {
    if (!currentRoomId) return;

    try {
        const res = await fetch(`/chat/${currentRoomId}/poll?since=${lastMsgId}`, {
            headers: { 'Accept': 'application/json' }
        });
        if (!res.ok) return;

        const msgs = await res.json();
        if (!msgs.length) return;

        const area    = document.getElementById('messages-area');
        const atBottom = area.scrollHeight - area.scrollTop - area.clientHeight < 60;

        // Remove empty state
        const empty = document.querySelector('.empty-state');
        if (empty) empty.remove();

        msgs.forEach(msg => {
            // Skip if already rendered (our own sent messages)
            if (document.getElementById('msg-' + msg.id)) return;
            area.appendChild(renderMessage(msg));
            lastMsgId = Math.max(lastMsgId, msg.id);
        });

        if (atBottom) scrollBottom(true);
    } catch (e) {
        // Silent fail on poll
    }
}

// ── Switch room ──────────────────────────────────────────────────────────────
async function switchRoom(roomId, name, type, desc) {
    if (roomId === currentRoomId) return;

    currentRoomId = roomId;
    lastMsgId     = 0;

    // Update active sidebar item
    document.querySelectorAll('.room-item').forEach(el => {
        el.classList.toggle('active', parseInt(el.dataset.roomId) === roomId);
    });

    // Update header
    const icons = { general:'💬', claims:'📋', underwriting:'📊', support:'🎧' };
    document.getElementById('room-title').textContent = name;
    document.getElementById('room-desc').textContent  = desc;

    // Show loading
    const area = document.getElementById('messages-area');
    area.innerHTML = '<div class="msg-loading"><div class="spin"></div></div>';

    try {
        const res  = await fetch(`/chat/${roomId}/messages`, {
            headers: { 'Accept': 'application/json' }
        });
        const msgs = await res.json();

        area.innerHTML = '<div class="date-sep">Today</div>';

        if (!msgs.length) {
            area.innerHTML += `
                <div class="empty-state">
                    <div class="icon">💬</div>
                    <h3>No messages yet</h3>
                    <p>Be the first to start the conversation!</p>
                </div>`;
        } else {
            msgs.forEach(msg => {
                area.appendChild(renderMessage(msg));
                lastMsgId = Math.max(lastMsgId, msg.id);
            });
        }

        scrollBottom();
    } catch (e) {
        area.innerHTML = '<div class="empty-state"><div class="icon">⚠️</div><h3>Failed to load messages</h3></div>';
    }
}

// ── Start polling ─────────────────────────────────────────────────────────────
scrollBottom();
pollTimer = setInterval(pollMessages, 3000); // poll every 3 seconds

// Stop polling when tab is hidden
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        clearInterval(pollTimer);
    } else {
        pollTimer = setInterval(pollMessages, 3000);
    }
});
</script>
@endpush